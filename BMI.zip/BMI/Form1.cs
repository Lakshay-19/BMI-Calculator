﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Lakshay Punj
//April 4, 2019
//BMI calculator

namespace BMI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            //Declaring variables

            double Weight = double.Parse(txtWeight.Text);
            double Height = double.Parse(txtHeight.Text);

            //Program calculations and rounding

          if (Weight > 0 && Height > 0)
          {

            double BMI = Weight / (Math.Pow(Height, 2));
            BMI = Math.Round(BMI, 2);

            //If/Else Statements
            //Program runs if values above 0
            

                //Code for overweight BMI
                if (BMI > 25)
                {
                    lblOutput.Text = "You are Overweight, your BMI is " + BMI;
                }

                //Code for Normal weight BMI
                else if (BMI > 18.5 && BMI <= 25.0)
                {
                    lblOutput.Text = "You are Normal Weight, and your BMI is " + BMI;
                }

                //Code for Underweight BMI
                else if (BMI <= 18.5)
                {
                    lblOutput.Text = "You are Underweight, and your BMI is " + BMI;
                }
          }
          //Code for else value output
          else
            {
                lblOutput.Text = "Enter values above 0";
            }

          //Makes output visible when output
         lblOutput.Visible = true;
        }
    }
}
